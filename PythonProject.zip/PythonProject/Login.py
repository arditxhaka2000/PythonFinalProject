import customtkinter as ctk
import tkinter.messagebox as messagebox
import sqlite3

from Dashboard import Dashboard

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

def create_table():
    conn = sqlite3.connect('user_details.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 name TEXT NOT NULL,
                 surname TEXT NOT NULL,
                 email TEXT NOT NULL UNIQUE,
                 password TEXT NOT NULL);''')
    conn.commit()
    conn.close()

def login():
    email = email_entry.get()
    password = password_entry.get()

    conn = sqlite3.connect('user_details.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
    result = c.fetchone()
    conn.close()

    if result:
        status_label.configure("Successful")
        root.withdraw()  # Hide the login form
        dashboard_window = Dashboard(root)  
        root.wait_window(dashboard_window)
        root.deiconify()
    else:
        status_label.config(text="Invalid email or password")

def signup():
    signup_window = ctk.CTkToplevel(root)
    signup_window.lift(root)
    signup_window.grab_set()
    signup_window.title("Signup Form")
    signup_window.geometry("300x300")

    name_label = ctk.CTkLabel(signup_window, text="Name")
    name_label.pack()
    name_entry = ctk.CTkEntry(signup_window)
    name_entry.pack()

    surname_label = ctk.CTkLabel(signup_window, text="Surname")
    surname_label.pack()
    surname_entry = ctk.CTkEntry(signup_window)
    surname_entry.pack()

    email_label = ctk.CTkLabel(signup_window, text="Email")
    email_label.pack()
    email_entry_signup = ctk.CTkEntry(signup_window)
    email_entry_signup.pack()

    password_label = ctk.CTkLabel(signup_window, text="Password")
    password_label.pack()
    password_entry_signup = ctk.CTkEntry(signup_window, show="*")
    password_entry_signup.pack()

    def save_user():
        name = name_entry.get()
        surname = surname_entry.get()
        email = email_entry_signup.get()
        password = password_entry_signup.get()

        # Check if any field is empty
        if not name or not surname or not email or not password:
            messagebox.showerror("Signup", "All fields are required")
            return

        # Check if name and surname contain numbers
        if any(char.isdigit() for char in name) or any(char.isdigit() for char in surname):
            messagebox.showerror("Signup", "Name and surname cannot contain numbers")
            return

        conn = sqlite3.connect('user_details.db')
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (name, surname, email, password) VALUES (?, ?, ?, ?)",
                      (name, surname, email, password))
            conn.commit()
            messagebox.showinfo("Signup", "Signup completed")
            signup_window.destroy()

            dashboard_window = Dashboard(root)
            root.wait_window(dashboard_window)

        except sqlite3.IntegrityError:
            messagebox.showerror("Signup", "Signup exists")
            email_entry_signup.delete(0, ctk.END)  # Clear the input field
        finally:
            conn.close()

    save_button = ctk.CTkButton(signup_window, text="Save", command=save_user)
    save_button.pack()

root = ctk.CTk()
root.title("Login Form")
root.geometry("500x500")
frame = ctk.CTkFrame(master=root)
frame.pack(pady=20,padx=40,fill='both',expand=True)

email_label = ctk.CTkLabel(master=frame, text="Email")
email_label.pack(pady=12,padx=10)

email_entry = ctk.CTkEntry(master=frame)
email_entry.pack(pady=12,padx=10)

password_label = ctk.CTkLabel(master=frame, text="Password")
password_label.pack(pady=12,padx=10)
password_entry = ctk.CTkEntry(master=frame, show="*")
password_entry.pack(pady=12,padx=10)



login_button = ctk.CTkButton(master=frame, text="Login", command=login)
login_button.pack(pady=12,padx=10)

signup_button = ctk.CTkButton(master=frame, text="Signup", command=signup)
signup_button.pack(pady=12,padx=10)

status_label = ctk.CTkLabel(master=frame, text="")
status_label.pack()
dashboard_window = Dashboard(root)  
root.wait_window(dashboard_window)
root.deiconify()
create_table()

root.mainloop()
