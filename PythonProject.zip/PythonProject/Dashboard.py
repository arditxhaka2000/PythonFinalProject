import customtkinter as ctk
import tkinter.messagebox as messagebox
import sqlite3
from tkinter import ttk

class Dashboard(ctk.CTkToplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Dashboard")
        self.geometry("400x300")

        self.total_sales_label = ctk.CTkLabel(self, text="Total Sales: $0")
        self.total_sales_label.grid(row=0, column=0, columnspan=2, pady=10)

        operations_frame = ctk.CTkFrame(self)
        operations_frame.grid(row=1, column=0, padx=10)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)

        stock_button = ctk.CTkButton(operations_frame, text="Stock", command=self.open_stock)
        stock_button.pack(pady=5)
        
        add_stock_button = ctk.CTkButton(operations_frame, text="Add Stock", command=self.open_stock)
        add_stock_button.pack(padx=10, pady=10)

        sales_button = ctk.CTkButton(operations_frame, text="Sales", command=self.open_sales)
        sales_button.pack(pady=5)

        reports_button = ctk.CTkButton(operations_frame, text="Reports", command=self.open_reports)
        reports_button.pack(pady=5)

        pos_button = ctk.CTkButton(operations_frame, text="POS", command=self.open_pos, anchor="right" )
        pos_button.pack(pady=5)
         
        self.action_frame = ctk.CTkFrame(self)
        self.action_frame.grid(row=1, column=1, padx=10, sticky = "NSEW")

        logout_button = ctk.CTkButton(operations_frame, text="Log Out", command=self.logout)
        logout_button.pack(pady=10)

    def open_stock(self):
       if hasattr(self, 'stock_treeview'):
            self.sales_treeview.lift()
       else:
            conn = sqlite3.connect('user_details.db')
            c = conn.cursor()
            c.execute("SELECT * FROM Product")
            result = c.fetchall()
            conn.close()

            if result:
                # Create the treeview widget as a child of self.action_frame
                self.sales_treeview = ttk.Treeview(self.action_frame)
                self.sales_treeview['columns'] = ('ID', 'Name', 'Price', 'Quantity', 'Category')

                # Define column headings
                self.sales_treeview.heading('ID', text='ID')
                self.sales_treeview.heading('Name', text='Name')
                self.sales_treeview.heading('Price', text='Price')
                self.sales_treeview.heading('Quantity', text='Quantity')
                self.sales_treeview.heading('Category', text='Category')

                # Add rows to the treeview
                for row in result:
                    self.sales_treeview.insert('', 'end', values=row)

                # Configure the treeview to expand with its container
                self.sales_treeview.grid(row=0, column=0, sticky='nsew')

            else:
                messagebox.showinfo("Sales", "No sales data available.")


    def open_stock_Add(self):
        stock_window = ctk.CTkToplevel(self)
        stock_window.title("Add Stock")

        # Create the stock entry fields and button
        stock_frame = ctk.CTkFrame(stock_window)
        stock_frame.pack(padx=10, pady=10)

        stock_name_label = ctk.CTkLabel(stock_frame, text="Product Name:")
        stock_name_label.pack(side='left')
        stock_name_entry = ctk.CTkEntry(stock_frame)
        stock_name_entry.pack(side='left')

        stock_quantity_label = ctk.CTkLabel(stock_frame, text="Quantity:")
        stock_quantity_label.pack(side='left')
        stock_quantity_entry = ctk.CTkEntry(stock_frame)
        stock_quantity_entry.pack(side='left')

        stock_price_label = ctk.CTkLabel(stock_frame, text="Price:")
        stock_price_label.pack(side='left')
        stock_price_entry = ctk.CTkEntry(stock_frame)
        stock_price_entry.pack(side='left')

        add_stock_button = ctk.CTkButton(stock_frame, text="Add Stock", command=lambda: self.add_stock(
            stock_name_entry.get(), stock_quantity_entry.get(), stock_price_entry.get()))
        add_stock_button.pack(side='left')

    def add_stock(self, name, quantity, price):
        conn = sqlite3.connect('user_details.db')
        c = conn.cursor()
    
        # Check if the stock item already exists
        c.execute("SELECT * FROM Product WHERE Name=?", (name,))
        existing_item = c.fetchone()
    
        if existing_item:
            # If the item exists, update the quantity and price
            new_quantity = int(existing_item[3]) + int(quantity)
            new_price = float(existing_item[2]) + float(price)
            c.execute("UPDATE Product SET Quantity=?, Price=? WHERE Name=?", (new_quantity, new_price, name))
        else:
            # If the item doesn't exist, insert a new row
            c.execute("INSERT INTO Product (Name, Price, Quantity) VALUES (?, ?, ?)", (name, price, quantity))
    
        conn.commit()
        conn.close()
    
        # Refresh the treeview to reflect the updated data
        self.refresh_sales_treeview()
    
    def refresh_sales_treeview(self):
        conn = sqlite3.connect('user_details.db')
        c = conn.cursor()
        c.execute("SELECT * FROM Product")
        result = c.fetchall()
        conn.close()
        self.sales_treeview = ttk.Treeview(self.action_frame)
        # Clear the treeview
        self.sales_treeview.delete(*self.sales_treeview.get_children())
    
        # Add rows to the treeview
        for row in result:
            self.sales_treeview.insert('', 'end', values=row)
    
    
    def open_sales(self):
        if hasattr(self, 'sales_treeview'):
            self.sales_treeview.lift()
        else:
            conn = sqlite3.connect('user_details.db')
            c = conn.cursor()
            c.execute("SELECT * FROM sales")
            result = c.fetchall()
            conn.close()

            if result:
                # Create the treeview widget as a child of self.action_frame
                self.sales_treeview = ttk.Treeview(self.action_frame)
                self.sales_treeview['columns'] = ('ID', 'Product', 'Price', 'Quantity')

                # Define column headings
                self.sales_treeview.heading('ID', text='ID')
                self.sales_treeview.heading('Product', text='Product')
                self.sales_treeview.heading('Price', text='Price')
                self.sales_treeview.heading('Quantity', text='Quantity')

                # Add rows to the treeview
                for row in result:
                    self.sales_treeview.insert('', 'end', values=row)

                # Configure the treeview to expand with its container
                self.sales_treeview.grid(row=0, column=0, sticky='nsew')

                # Configure the grid cell to expand with self.action_frame
                self.action_frame.columnconfigure(0, weight=1)
                self.action_frame.rowconfigure(0, weight=1)
            else:
                messagebox.showinfo("Sales", "No sales data available.")



    def open_reports(self):
        # TODO: Open the reports form or perform any desired action
        pass

    def open_pos(self):
        # TODO: Open the POS form or perform any desired action
        pass

    def logout(self):
        self.destroy()
        self.master.deiconify()

def main():
    root = ctk.CTk()
    root.mainloop()
    ctk.set_appearance_mode("dark")
  
    ctk.set_default_color_theme("blue")
if __name__ == "__main__":
    main()
